    </main>
</div>

<footer class="app-footer">
    <small>© <?php echo date('Y'); ?> Manajemen Keuangan Pribadi - UTS Pengembangan Web</small>
</footer>

<script src="/keuangan_pribadi/public/assets/js/app.js"></script>
</body>
</html>
